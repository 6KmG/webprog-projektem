from logger import log

@log('i')
def example():
    print("hi")

example()
