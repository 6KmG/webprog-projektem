package com.secondhandcar.secondhandcar.exceptions;

public class NoPre2010CarsException extends Exception{
    public NoPre2010CarsException(String message){
        super.getMessage();
    }
}
