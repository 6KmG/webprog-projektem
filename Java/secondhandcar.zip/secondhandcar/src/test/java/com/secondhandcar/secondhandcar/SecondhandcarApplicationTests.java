package com.secondhandcar.secondhandcar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecondhandcarApplicationTests {

	@Test
	void contextLoads() {
	}

}
