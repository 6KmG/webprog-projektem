// Alkalmazás inicializálása
Controller.AppInit();
