<?php 
echo '<nav>
            <ul>
                <li><a href="?content=home">Bemutató</a></li>
                <li><a href="?content=program">Programok</a></li>
                <li><a href="?content=gallery">Galéria</a></li>
                <li><a href="?content=contact">Elérhetőségek</a></li>
            </ul>
        </nav>';
?>