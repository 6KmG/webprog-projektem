package com.todoapi.todoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
